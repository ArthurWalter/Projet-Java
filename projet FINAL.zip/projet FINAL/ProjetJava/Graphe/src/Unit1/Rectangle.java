package Unit1;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Rectangle extends ObjetDeBase implements MouseListener {
//les attributs	
	public Point2D point2;
	public static int indiceobj; 
//1 ObjetDeBase, 2 ObjetComposite, 3 MultiRectangle
	private JPanel pf=new JPanel(); //panel de font
	private static JTextField tf1=new JTextField(""); 
	private static JTextField tf2=new JTextField("");
	private JTextField tf3=new JTextField(""); 
	private JTextField tf4=new JTextField("");
	private JButton bretour=new JButton("Retourner"); 
	private JButton bafficher=new JButton("Afficher");
//constructeur 	
	public Rectangle(){	
		System.out.println("Rectangle");
	}
//constructeur principal	
	public Rectangle(int i) {
		Init();
	}
//Initialiser le panel et l'ajouter dans le panel centre de l'Accueil
	public void Init() {
		Accueil.Clear();
		Accueil.Add(this.pf);
//config les 3 panels 	
		JPanel p1=new JPanel();		//p2:panel haut
		JPanel p2=new JPanel(); 	//p3:panel milieu
		JPanel p3=new JPanel();		//p4:panel bas
		//config gridlayout pour ranger les trois panels						  	
		this.add(pf);
		pf.setLayout(new GridLayout(3,1));
		pf.add(p1);
		pf.add(p2);
		pf.add(p3);
//config panel haut
		//config label
		JLabel l1=new JLabel("Rectangle");
		//config borderlayout
		BorderLayout bl1=new BorderLayout();
		p1.setLayout(bl1);
		p1.add(l1);
		//les alignement fonctionnnent qu'avec un borderlayout
		l1.setHorizontalAlignment(JLabel.CENTER);
		l1.setVerticalAlignment(JLabel.CENTER);
//config panel milieu
		JPanel p21=new JPanel();
		JPanel p22=new JPanel();
		p2.setLayout(new GridLayout(2,1));
		p2.add(p21);
		p2.add(p22);
		//config panel milieu 1
		JLabel l2=new JLabel("Entrez les paramètres: ");
		p21.add(l2);
		//config panel milieu 2
		p22.setLayout(new GridLayout(2,3));
		JLabel l21=new JLabel("Les coordonnées du point référentiel: ");
		JLabel l22=new JLabel("Les coordonnées du point référentiel 2: ");
		l21.setHorizontalAlignment(JLabel.CENTER);
		l22.setHorizontalAlignment(JLabel.CENTER);
		p22.add(l21);
		p22.add(tf1);
		p22.add(tf2);
		p22.add(l22);
		p22.add(tf3);
		p22.add(tf4);
//config panel bas
		p3.add(bretour);
		p3.add(bafficher);
		bretour.addMouseListener(this);
		bafficher.addMouseListener(this);
	}
//les fonctions
	public Point2D getPoint2(){
		return point2;
	}
	public void setPoint2(Point2D p){
		this.point2 =p;
	}
//afficher le message
@Override
	public String toString() {
		return "Rectangle [pointref="+pointref+
				", point2="+point2 + "]";
	}
//Mouse Listener
	public void mouseClicked(MouseEvent e){
		if (e.getSource()==bretour) 
		{	if (indiceobj==2)
			{
				Accueil.Clear();
				Accueil.Add(new ObjetComposite(1));
			}
			else if (indiceobj==3)
			{
				Accueil.Clear();
				Accueil.Add(new AccueilPanel());
			}
			else {
				Accueil.Clear();
				Accueil.Add(new ObjetDeBase(1));
			}
		}
		else if (e.getSource()==bafficher)
		{	//récupérer les coordonnées des 2 points
			try
			{
				String str1=tf1.getText();
				String str2=tf2.getText();
				String str3=tf3.getText(); 
				String str4=tf4.getText();
				this.pointref=new Point2D(Integer.parseInt(str1),Integer.parseInt(str2));
				this.point2=new Point2D(Integer.parseInt(str3),Integer.parseInt(str4));
				PanelDraw pd=new PanelDraw(this);
				if(indiceobj==3) 
				{
					Multirectangle.pointref=this.pointref;
					tf1.setText(str1);
					tf2.setText(str2);
					PanelDraw.Add(this);//MultiRectangle
				}
				else if(indiceobj==1){
					PanelDraw.DeleteAll();
				}
				else {
					tf1.setText("");//supprimer le contenu dans tf
					tf2.setText("");
				}
			}
			catch(Exception ef)
			{
				System.out.println("Vous n'avez pas saisi de coordonnées ou vous avez oublié une coordonnée");
			}
		}
	}
	public void mousePressed(MouseEvent e)
	{
		
	}
	public void mouseReleased(MouseEvent e)
	{
		
	}
	public void mouseEntered(MouseEvent e)
	{
		
	}
	public void mouseExited(MouseEvent e)
	{
		
	}
}
