package Unit1;
import javax.swing.JPanel;

public class Objet extends JPanel{
	
	
}
