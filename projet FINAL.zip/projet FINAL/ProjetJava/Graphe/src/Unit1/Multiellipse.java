package Unit1;

public class Multiellipse {
	public static Point2D pointref;
//constructeur		
	public Multiellipse(){
		System.out.println("Multi");
	}
//constructeur principal
	public Multiellipse(int i) {
		Init();
	}
//Initialiser le panel et l'ajouter dans le panel centre de l'Accueil
	public void Init() {
		Accueil.Clear();
		Accueil.Add(new Ellipse(1));
		PanelDraw.indiceobj=5;//Multiellipse
		Ellipse.indiceobj=3;//MultiEllipse
	}
}
