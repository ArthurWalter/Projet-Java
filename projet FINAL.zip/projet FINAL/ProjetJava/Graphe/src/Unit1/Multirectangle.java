package Unit1;

public class Multirectangle  {
	public static Point2D pointref;
//constructeur	
	public Multirectangle(){
		System.out.println("Multi");
	}
//constructeur principal
	public Multirectangle(int i) {
		Init();
	}
//Initialiser le panel et l'ajouter dans le panel centre de l'Accueil
	public void Init() {
		Accueil.Clear();
		Accueil.Add(new Rectangle(1));
		PanelDraw.indiceobj=3;//MultiRectangle
		Rectangle.indiceobj=3;//MultiRectangle
	}
}