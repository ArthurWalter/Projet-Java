package Unit1;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.awt.event.MouseEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JScrollPane;

public class Gest extends JPanel implements MouseListener,ListSelectionListener {
	private static ArrayList<ObjetDeBase> al=new ArrayList();
	public  static ObjetDeBase odb;
	private static DefaultListModel<String> dlm=new DefaultListModel();
	private static JList<String> list =new JList<String>(dlm); 	//list	
	private JScrollPane sp=new JScrollPane(list);//construire avec le composant 
	private JPanel pf=new JPanel();
	private JButton bremove=new JButton("Supprimer"); 
	private JButton bafficher=new JButton("Afficher");
//constructeur principal	
	public Gest() {
		Init();
	}
//Initialiser le panel et l'ajouter dans le panel centre de l'Accueil
	public void Init() {
		Accueil.ClearAdd2(pf);
		//config gridlayout pour ranger les trois panels 	
		pf.setLayout(new BorderLayout());
		JPanel p1=new JPanel(); //panel haut
		JPanel p2=new JPanel(); //panel milieu
		JPanel p3=new JPanel(); //panel bas
		pf.add(p1,BorderLayout.NORTH);
		pf.add(p2,BorderLayout.CENTER);
		pf.add(p3,BorderLayout.SOUTH);
		//panel haut
		JLabel l1=new JLabel("Liste des Objets");
		p1.add(l1);
		//panel milieu
		p2.setLayout(new BorderLayout());
		p2.add(sp,BorderLayout.CENTER);
		//panel bas
		p3.add(bremove);
		p3.add(bafficher);
		bremove.addMouseListener(this);
		bafficher.addMouseListener(this);
		list.addListSelectionListener(this);
	}
//Ajouter un element dans la liste droite et ArrayList al
	public static void Add(ObjetDeBase odb) {
		dlm.addElement(odb.toString());
		System.out.println("Objet ajouté");
		al.add(odb);
	}
//Mouse Listener
	public void mouseClicked(MouseEvent e){
		//supprimer l'élément qu'on a séléctionné
		if (e.getSource()==bremove) 
		{	
			dlm.remove(list.getLeadSelectionIndex());
			al.remove(list.getLeadSelectionIndex());
			System.out.println("Objet supprimé");
		}
		else if (e.getSource()==bafficher) {
			this.odb=al.get(list.getLeadSelectionIndex());
			PanelDraw pd=new PanelDraw(odb);	
		}
	}
	public void mousePressed(MouseEvent e)
	{
		
	}
	public void mouseReleased(MouseEvent e)
	{
		
	}
	public void mouseEntered(MouseEvent e)
	{
		
	}
	public void mouseExited(MouseEvent e)
	{
		
	}
//ListSelection Listener	
	@Override
	public void valueChanged(ListSelectionEvent e) {
		if(!e.getValueIsAdjusting())
		{
			System.out.println("sélectioné");
		}
	}		
}
